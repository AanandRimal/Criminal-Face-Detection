import pymysql

def insertData(data):
    rowId = 0

    db = pymysql.connect(host='localhost', user='root', password='', database='criminaldb')
    cursor = db.cursor()
    print("database connected")

    query = "INSERT INTO criminaldata VALUES('%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s');" % \
            (data["Name"], data["Father's Name"], data["Mother's Name"], data["Gender"],
             data["DOB(yyyy-mm-dd)"], data["Blood Group"], data["Identification Mark"],
             data["Nationality"], data["Religion"], data["Crimes Done"])

    try:
        cursor.execute(query)
        db.commit()

        rowId =6  #cursor.lastrowid
        print("data stored on row %d" % rowId)
    except Exception as e:
        db.rollback()
        print(e)


    db.close()
    print("connection closed")
    return rowId

def retrieveData(name):
    id = None
    crim_data = None

    db = pymysql.connect(host='localhost', user='root',password='', database='criminaldb')
    cursor = db.cursor()
    print("database connected")

    query = "SELECT * FROM criminaldata WHERE name='saurav'"

    try:
        cursor.execute(query)
        result = cursor.fetchone()

        id=7
        crim_data = {
            "Name" : result[0],
            "Father's Name" : result[1],
            "Mother's Name" : result[2],
            "Gender" : result[3],
            "DOB(yyyy-mm-dd)" : result[4],
            "Blood Group" : result[5],
            "Identification Mark" : result[6],
            "Nationality" : result[7],
            "Religion" : result[8],
            "Crimes Done" : result[9]
        }

        print("data retrieved")
    except:
        print("Error: Unable to fetch data")

    db.close()
    print("connection closed")

    return (id, crim_data)
